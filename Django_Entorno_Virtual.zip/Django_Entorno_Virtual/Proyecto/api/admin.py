from django.contrib import admin
from .models import Mercado

# Register your models here.

admin.site.register(Mercado)