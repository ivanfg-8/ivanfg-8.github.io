from django.shortcuts import render, redirect
from .models import Mercado

# Create your views here.

def home(request):
    return render(request, "index.html")

def registro(request):
    return render(request, "registro.html")

def registrarMercado(request):
    id_mercado=request.POST['numero']
    nombre_mercado=request.POST['nombre']
    tipo_mercado=request.POST['tipo']
    codigo_postal_mercado=request.POST['codigo_postal']
    alcaldia_mercado=request.POST['alcaldia']
    colonia_mercado=request.POST['colonia']
    calle_mercado=request.POST['calle']

    mercado = Mercado.objects.create(id_mercado=id_mercado, nombre_mercado=nombre_mercado, tipo_mercado=tipo_mercado, 
                                     codigo_postal_mercado=codigo_postal_mercado,alcaldia_mercado=alcaldia_mercado, 
                                     colonia_mercado=colonia_mercado, calle_mercado=calle_mercado)
    return redirect('/')