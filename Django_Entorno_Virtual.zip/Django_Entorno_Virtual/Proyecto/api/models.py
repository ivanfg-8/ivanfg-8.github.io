from django.db import models

# Create your models here.

class Mercado(models.Model):
    id_mercado=models.CharField(primary_key=True,max_length=6)
    nombre_mercado=models.CharField(max_length=40)
    tipo_mercado=models.CharField(max_length=30)
    codigo_postal_mercado=models.PositiveBigIntegerField()
    alcaldia_mercado=models.CharField(max_length=30)
    colonia_mercado=models.CharField(max_length=30)
    calle_mercado=models.CharField(max_length=40)

    def __str__(self):
        texto = "{0} {1}"
        return texto.format(self.id_mercado, self.nombre_mercado)